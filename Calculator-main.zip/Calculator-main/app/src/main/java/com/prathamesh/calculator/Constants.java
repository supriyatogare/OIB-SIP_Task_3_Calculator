package com.prathamesh.calculator;

public class Constants {
    public static int SPLASH = 3000;
}
